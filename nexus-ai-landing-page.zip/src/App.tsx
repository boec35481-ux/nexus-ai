import React, { useEffect, useRef } from 'react';

interface Node {
  x: number;
  y: number;
  vx: number;
  vy: number;
}

const GeometricBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const nodes: Node[] = [];
    const nodeCount = Math.min(42, Math.floor((window.innerWidth * window.innerHeight) / 18000));

    for (let i = 0; i < nodeCount; i++) {
      nodes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.18,
        vy: (Math.random() - 0.5) * 0.18,
      });
    }

    let animationFrame: number;
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Subtle grid
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.06)';
      ctx.lineWidth = 1;
      const gridSize = 52;
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // Update & draw nodes
      ctx.strokeStyle = 'rgba(147, 197, 253, 0.14)';
      ctx.fillStyle = 'rgba(147, 197, 253, 0.65)';
      ctx.lineWidth = 1;

      nodes.forEach((node, i) => {
        node.x += node.vx;
        node.y += node.vy;

        if (node.x < 0 || node.x > canvas.width) node.vx *= -1;
        if (node.y < 0 || node.y > canvas.height) node.vy *= -1;

        // Draw connections
        for (let j = i + 1; j < nodes.length; j++) {
          const other = nodes[j];
          const dx = node.x - other.x;
          const dy = node.y - other.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 170) {
            const alpha = (1 - dist / 170) * 0.55;
            ctx.strokeStyle = `rgba(147, 197, 253, ${alpha})`;
            ctx.beginPath();
            ctx.moveTo(node.x, node.y);
            ctx.lineTo(other.x, other.y);
            ctx.stroke();
          }
        }

        // Node
        ctx.fillStyle = i % 3 === 0 
          ? 'rgba(103, 232, 249, 0.75)' 
          : 'rgba(147, 197, 253, 0.65)';
        ctx.beginPath();
        ctx.arc(node.x, node.y, i % 4 === 0 ? 2.1 : 1.45, 0, Math.PI * 2);
        ctx.fill();
      });

      animationFrame = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationFrame);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-0 pointer-events-none"
      style={{ opacity: 0.9 }}
    />
  );
};

const Navbar: React.FC = () => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition - bodyRect - offset;
      window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-white/10 bg-[#0a1628]/80 backdrop-blur-xl">
      <div className="max-w-6xl mx-auto px-8 flex items-center justify-between h-20">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-sky-400 to-blue-500 flex items-center justify-center">
            <div className="w-3.5 h-3.5 rounded-sm bg-[#0a1628]" />
          </div>
          <div className="font-semibold tracking-[-0.025em] text-xl text-white">NEXUS</div>
          <div className="text-[10px] font-mono tracking-[3px] text-white/40 pl-1 pt-0.5">AI STRATEGY</div>
        </div>

        <div className="flex items-center gap-9 text-sm font-medium text-white/70">
          <button 
            onClick={() => scrollToSection('what-we-do')} 
            className="hover:text-white transition-colors duration-200"
          >
            What We Do
          </button>
          <a 
            href="mailto:nexus.products.ai@gmail.com" 
            className="px-5 py-2.5 rounded-full border border-white/20 hover:bg-white/5 hover:border-white/30 transition-all duration-200 text-white"
          >
            Contact
          </a>
        </div>
      </div>
    </nav>
  );
};

const Hero: React.FC = () => {
  return (
    <div className="relative min-h-[100dvh] flex items-center justify-center pt-20 px-6">
      <div className="relative z-10 max-w-4xl text-center">
        <div className="inline-block mb-5 px-4 py-1 rounded-full border border-white/10 bg-white/[0.025] text-xs tracking-[3px] text-white/50 font-mono">
          LONDON · DUBAI · SINGAPORE
        </div>

        <h1 className="text-7xl md:text-[84px] font-semibold tracking-[-4.4px] leading-[0.92] text-white mb-6">
          AI Infrastructure<br />for Capital Markets
        </h1>

        <p className="max-w-lg mx-auto text-xl text-white/60 tracking-tight mb-12">
          We help Fintech &amp; Web3 companies deploy production-ready AI agents.
        </p>

        <a
          href="mailto:nexus.products.ai@gmail.com"
          className="group inline-flex items-center justify-center gap-3 px-9 py-[19px] bg-white text-[#0a1628] rounded-full text-[15px] font-medium tracking-[-0.2px] hover:bg-white/90 active:scale-[0.985] transition-all duration-200 shadow-xl shadow-black/30"
        >
          Contact Us
          <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 group-hover:translate-x-0.5 transition" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.25} d="M17 8l4 4m0 0l-4 4m4-4H3" />
          </svg>
        </a>

        <div className="absolute bottom-16 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 text-[10px] tracking-[2px] text-white/30">
          SCROLL TO EXPLORE
          <div className="w-px h-8 bg-gradient-to-b from-white/20 to-transparent" />
        </div>
      </div>
    </div>
  );
};

const WhatWeDo: React.FC = () => {
  const services = [
    {
      title: "RWA Liquidity Bridges",
      desc: "Connecting tokenized assets to institutional capital.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.75} d="M13 10V3L4 14h7v7l9-11h-7z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.75} d="M19 15l-7-7" />
        </svg>
      ),
    },
    {
      title: "AI Agents",
      desc: "Autonomous payment routing & compliance automation.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.75} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 8.5a2.5 2.5 0 115 0 2.5 2.5 0 01-5 0zM19 8.5a2.5 2.5 0 115 0 2.5 2.5 0 01-5 0z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.75} d="M12 3v5" />
        </svg>
      ),
    },
    {
      title: "Strategic Partnerships",
      desc: "Infra integration for L2s and payment rails.",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.75} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 4.01V8" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.75} d="M12 21v-9" />
        </svg>
      ),
    },
  ];

  return (
    <section id="what-we-do" className="relative z-10 max-w-6xl mx-auto px-8 pt-20 pb-24">
      <div className="mb-14 text-center">
        <div className="inline text-xs tracking-[3.5px] font-mono text-sky-400/70">EXPERTISE</div>
        <h2 className="mt-3 text-5xl font-semibold tracking-[-2.6px] text-white">What We Do</h2>
      </div>

      <div className="grid md:grid-cols-3 gap-5">
        {services.map((service, index) => (
          <div
            key={index}
            className="group rounded-3xl border border-white/[0.07] bg-white/[0.02] backdrop-blur-3xl p-9 flex flex-col transition-all duration-500 hover:border-white/15 hover:bg-white/[0.04]"
          >
            <div className="mb-auto">
              <div className="inline-flex w-12 h-12 rounded-2xl bg-white/[0.04] text-sky-400/90 group-hover:text-sky-300 items-center justify-center mb-8 border border-white/5 transition-colors">
                {service.icon}
              </div>
              <h3 className="font-semibold text-2xl tracking-[-1.4px] text-white leading-tight mb-4">
                {service.title}
              </h3>
              <p className="text-white/60 leading-relaxed tracking-tight pr-4">
                {service.desc}
              </p>
            </div>
            <div className="pt-9 mt-auto border-t border-white/10 text-xs font-mono tracking-[2px] text-white/30 group-hover:text-white/50 transition-colors">
              LEARN MORE →
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

const Footer: React.FC = () => {
  return (
    <footer className="relative z-10 border-t border-white/10 bg-[#0a1628]">
      <div className="max-w-6xl mx-auto px-8 py-16 md:py-20">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-y-10">
          <div>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-sky-400 to-blue-500 flex items-center justify-center">
                <div className="w-3.5 h-3.5 rounded-sm bg-[#0a1628]" />
              </div>
              <div>
                <div className="font-semibold text-xl tracking-[-0.5px] text-white">Nexus AI Strategy Ltd</div>
              </div>
            </div>
            <div className="font-mono text-xs text-white/50 tracking-[2.4px]">LONDON · DUBAI · SINGAPORE</div>
          </div>

          <div className="text-sm text-white/70 max-w-[280px]">
            <a href="mailto:nexus.products.ai@gmail.com" className="hover:text-white underline-offset-4 hover:underline transition">
              nexus.products.ai@gmail.com
            </a>
          </div>
        </div>

        <div className="pt-14 mt-16 border-t border-white/10 text-[11px] text-white/30 tracking-widest font-mono flex justify-between items-center">
          <div>© {new Date().getFullYear()} NEXUS AI STRATEGY LTD</div>
          <div>CONFIDENTIAL</div>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <div className="bg-[#0a1628] text-white overflow-x-hidden min-h-screen font-sans selection:bg-sky-400/30 selection:text-white">
      <GeometricBackground />
      
      {/* Subtle top gradient glow */}
      <div className="fixed inset-x-0 top-0 h-[380px] bg-gradient-to-b from-[#0f213b] via-[#0a1628] to-transparent z-0 pointer-events-none" />

      <Navbar />
      <Hero />
      <WhatWeDo />
      <Footer />
    </div>
  );
}
